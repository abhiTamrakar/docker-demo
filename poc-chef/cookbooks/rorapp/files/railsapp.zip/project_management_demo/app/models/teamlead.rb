class Teamlead < ApplicationRecord
  has_many :projects
end
