class CreateProjects < ActiveRecord::Migration[5.2]
  #  def change
  #    create_table :projects do |t|
  #
  #      t.timestamps
  #    end
  #  end
  
  def self.up
    create_table :projects do |t|
      t.column :title, :string, :limit => 32, :null => false
      t.column :teamlead_id, :integer
      t.column :description, :text
      t.column :created_at, :timestamp
    end
  end

  def self.down
    drop_table :projects
  end
end
