# inspec file for ror app server
control 'applications' do
  impact 0.7
  title 'applications should be installed and running'

app_services = yaml(content: inspec.profile.file('services.yml')).params

app_services.each do |s|
  describe service(s['service_name']) do
    it { should be_running }
    it { should be_enabled }
end

describe port(s['port']) do
  it { should be_listening }
  end
end

end
