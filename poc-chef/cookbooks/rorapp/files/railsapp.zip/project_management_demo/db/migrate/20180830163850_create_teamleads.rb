class CreateTeamleads < ActiveRecord::Migration[5.2]
#  def change
#    create_table :teamleads do |t|
#
#      t.timestamps
#    end
#  end
  
  def self.up
      
    create_table :teamleads do |t|
      t.column :name, :string
    end
	
    Teamlead.create :name => "Peter"
    Teamlead.create :name => "Mike"
    Teamlead.create :name => "John"
  end

  def self.down
    drop_table :teamleads
  end
end
