# inspec file for ror app server
control 'db' do
  impact 0.7
  title 'applications should be installed and running'

db_services = yaml(content: inspec.profile.file('dbservices.yml')).params

db_services.each do |s|
  describe service(s['service_name']) do
    it { should be_running }
    it { should be_enabled }
  end

  describe port(s['port']) do
    it { should be_listening }
  end
end

describe service('metricbeat') do
    it { should be_running }
    it { should be_enabled }
end

end
